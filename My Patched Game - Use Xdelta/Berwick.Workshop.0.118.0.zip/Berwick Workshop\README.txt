Berwick Workshop
Version 0.118.0

A data browser and editor for Berwick Saga: Lazberia Chronicle, Chapter 174 on PlayStation 2.


What it does

Opens an uncompressed ISO of the game, confirms which edition it is, and shows:

Items: might, accuracy, weight, range, critical, level, base price, durability grade and special effect for every item. Search by name or ID and filter by type.

Characters: the starting record of all 35 recruitable characters, including class, level, base stats, stat bonuses over the class base, growth rates, weapon growth, weapon levels, personal skills, skills learned on level up, starting items, bag contents, partners and mercenary fees.

Armies: every unit in the game's armies, 3,042 units in 275 armies: enemies, bosses, guests and the units of story scenes, with class, level, stat bonuses, weapon levels, skills, items and the items each unit drops when defeated. Named units only (on by default) shows the units with a name of their own, such as bosses and leaders. Unit names, and mission and quest titles, are shown in English on both editions. Where the game's events show which battle places an army, the army is named after it, for example Army 371 (Quest 6: Cruel Brothers); searching for a mission or quest title lists its armies. This covers 159 of the 275 armies; the others, such as your own units, appear in many battles or in story scenes.

Furniture: the 13 pieces the furniture shop sells, their prices and what each piece does while it is shown in Reese's room. The bonuses go to Reese only; their sizes are on the Game rules page under Furniture in Reese's room, where the Maiden Statue's Miracle can also be turned off. The Luxury Bed is meant to raise Reese's HP growth, but the game ignores it.

Dishes: the 54 dishes of the Kingfisher Pavilion by the game's own names, with price, menu tier, kind and three sets of effects (liked, neutral, disliked), each up to four of the game's own effects such as Strength, HP, Sleep-Proof or EXP Rate Up, and who likes and dislikes each dish. Everything can be edited, and each character's tastes are edited on the Characters page under Dish tastes. The random menu never offers kind 4, the drinks. The menu rounds prices down to tens, and its daily special costs 20% less (30% after the arena quest).

Text: the game's texts on both discs: the 4,164 short texts (names of items, classes, units, skills and dishes, skill explanations, meal effects, quest titles and summaries, mission and chapter titles, town texts and status and menu words), mission and quest descriptions, event items, guide messages and all of the dialogue. In dialogue and other longer texts a new line starts a new line in the game, and the game's codes show in braces, such as {84:2} for who speaks; keep them where they are. Help and hint texts are not included. Search them, filter by kind and change any of them. Only characters the game's font has can be used; anything else is pointed out before a change is made. Changed item and dish names show on the other pages too, and every copy of the texts is changed on export.

Shops: what every shop sells, at the base and on battle maps, and how each item is sold.

Classes: base stats, movement, movement type, experience value, class skills and weapon level caps for every class, and which characters start in each one.

Battle animations: which animation set each class plays in battle and the colours each character wears in it, played back as in the game, with the sets no class uses. Both can be changed. Choose Export to save the current motion or all motions in the selected set as transparent PNG frames, sprite sheets, or both. Each motion has JSON with picture order, durations in 1/60-second ticks, cumulative start ticks, crop offsets and sheet rectangles. Choose Expanded canvas, Crop to the whole motion or Legacy 288 by 288. Expanded canvases fit visible body, weapon and shield tiles across the whole motion, preserving the same origin and dimensions for every frame. A shared crop preserves alignment across all frames. JSON version 2 records the canvas origin; original coordinates equal canvas origin plus crop offset plus pixel position within the frame. Export uses native pixels and the selected colours, independent of preview zoom. Large sprite sheets are split into numbered pages. Choose an existing location and a new export folder name; existing folders are never overwritten. Motions without display frames are skipped and counted. Cancel stops the export and removes its incomplete files. The export matches the preview's body, weapon and shield layers. Choose Effect layers with metadata in the Files list to export separate effect PNGs and their original records. All motions includes linked effects stored as separate motions. Each motion and track has its own folder, using the effect palette (effN.pal, falling back to eff0.pal). JSON retains hidden delays, source duration counters, next-record links, flags, offsets, scale, flips, depth and blend settings, plus original track, motion, keyframe and palette data. PNGs contain untransformed source artwork; they do not apply those settings or reproduce the final game composite. Nonzero pixels with nonzero source palette alpha are opaque in the PNG; original alpha values remain in the palette metadata. Source duration counters are preserved in their original 1/60-second units; initial/terminal tick phase, conditional branches and linked-motion playback are not simulated. Only Legacy 288 by 288 body output clips artwork outside that area. The selected set does not automatically resolve every held-weapon variant.

Movement: the terrain cost of every movement type (Cav, Knt, Fly and so on, as the game names them) on each of the 64 kinds of terrain, and which classes use each type.

Terrain: the avoid bonus, the change to recovery while resting, and whether flying units can end their move there, for each of the 64 kinds of terrain.

Maps: every battle's map as the game paints it, with its hex grid, terrain, spots, armies and where every unit starts. Deployment can be edited: tick Edit deployment and click hexes to add or remove places where your units can start, and set the most units you can deploy for each battle. The game marks only as many start hexes as that limit, the first ones in the order they were added. Tick Move units, click a unit, then click the hex where it should start the battle; units placed together in one slot move together. Click any unit on the map, one that starts there or one that arrives later, to see it under Selected unit and edit its class, level, bonuses, weapon levels, skills, items and drops there; clicking the same hex again picks the next unit on it. This works in every mode: right-click a hex, use the Every unit list in the details, or click a unit while moving units; with Edit deployment on, clicking a unit's hex shows the unit instead of changing deployment. A selected reinforcement also shows where and when it arrives: change its arrival hex (or pick it on the map) and its first turn. Units brought in by the same turn check change turn together, and arrivals set off by a spot or a conversation say so.

You can open a second disc to compare the two item by item, character by character and class by class. This also works for comparing a modified disc with the original.


Review changes

Choose Review changes to search every changed field, copied record, script, text and project name. Select a row to read the full original and current values. The Checks tab lists shared class and item users, starting bag and recipe references, equipment warnings, skill interactions and known conflicts. The Files tab lists the planned disc writes. Save manifest writes a JSON report to a new file. Project names are labels in the project file and do not rename game text.

Export opens this review first. Errors block export; review warnings describe effects to check before playing. Checks cover known dependencies, not every script behavior, later skill unlock or saved unit. Export also verifies the original disc and expected bytes.

Editing

Select an item, character or class and choose Edit (or press Ctrl+E).

Items: type, might, accuracy, weight, range, critical, level, base price, durability grade and durability pool; bonuses while equipped (strength, agility, defense, mind, hit, avoid, critical evade); fire, thunder, wind, holy and dark resistance; for horses, the stable price (what the stable charges, separate from the base price, for Thin Horse through Ish's Courser); the special effect with its chance or amount (for example poison, sleep, kill horse, disarm, injury, fire damage or block thunder); and effects such as strikes twice, ignores shields, no counterattack, drains HP, unbreakable or restores uses. Effects whose meaning is not clear from the game's own items are not offered.
Characters: class, level, stat bonuses over the class base, Luck, growth rates, growth bracket, weapon levels, weapon growth, personal skills, the first five starting items, bag contents, partners and mercenary fees.
The character details show Luck and weapon levels beside the level, and a table of expected HP, Strength, Defense, Agility and Mind at later levels: the starting value plus the growth rate times the levels gained, kept within the stat limits. The growth band holds real stats near these values on each level up: Loose within 3 for HP, Strength and Mind and 2 for Defense and Agility, Tight within 1.
Bag contents: Reese, Sherlock and Christine start with items in their bag. Each item can be changed or emptied; a bag cannot hold more items than it does on the disc.
Partners: sixteen characters have up to four partners, each with a bond. For every partner within 2 spaces, a unit gains hit equal to the bond divided by 10, and critical equal to the total of those amounts divided by 5. Ward has Reese at bond 40, so Ward gains 4 hit next to him. Bonds go from 0 to 1000. Partner changes also reach existing saves, because the game reloads partners whenever units are loaded.
Mercenary fees: eighteen characters can be hired, each with a base fee and a fee per level. The game charges the base fee plus the fee per level times the mercenary's level, and some hires cost half (the game marks this for each mercenary). Volo, for example, costs 200 plus 150 per level. When both values are 0 the game picks a random fee, as it does for Saphira. Fee changes apply to existing saves.
Armies: class, level, stat bonuses, weapon levels, personal skills, up to seven items with their durability or uses, and which items are dropped when the unit is defeated. Each army is stored twice on the disc and both copies are changed together. Changes take effect when a battle starts, so a save made before the battle uses them.
Shops: change, add or remove the items a shop sells (see Shops below).
Furniture: the price of each piece, from 1 to 99,999. The shop charges the price set here, and the export also writes it into the shop's list of pieces, which keeps the order of the original prices.
Classes: base stats, move, movement type, experience value, weapon level caps, shield sizes and class skills. A class can use a shield size only when that size is ticked and its shield level cap is above 0.
Movement: the cost of each kind of terrain for a movement type.
Terrain: avoid bonus, recovery while resting (in percent, negative for poison swamp), and whether flyers cannot stop there.

Edited entries are marked in the lists, and the details panel lists each change with its original value. Undo and Redo step through your changes, and Restore original values puts an entry back the way the disc has it.

Changing a character's class takes effect when they join, with the new class's base stats, movement and weapons; try it on a test export before a long playthrough. A class is shared by every unit in it, including enemies, so a class change affects all of them. To change one character only, edit that character's bonuses or personal skills instead. Weapon levels accept one decimal place, and weapon growth is set in steps of 10.

Growth bracket: stats grow toward start value plus growth rate times levels gained, and the bracket keeps them near that expectation. Loose keeps them within 3; Tight keeps them closer; None lets them drift (only Daoud and Lynette use None). The exact range of Tight has not been measured yet.


Randomize items

Randomize items on the Characters page replaces each starting item with a random item of the same type. You choose which kinds of items to include (weapons, orbs, staves and shields; arrows and bolts; accessories and consumables), whether bag contents are included, and whether a new item may have a higher level than the one it replaces. Items tied to one character or class, bags themselves, and items that cannot be bought or sold stay where they are. The same seed and options always give the same result, and the whole result is a single change you can undo.


New items

New item (Ctrl+N on the Items page) turns one of the disc's 156 unused item slots into a new item. It starts as a full copy of an item you choose, including properties the editor does not show yet, and can then be edited like any other item and given to characters as a starting item. Your name for the item is saved in the project. Until text editing is added, the game shows the slot's own name for it. Remove new item frees the slot again.

Movement and terrain

Each class has a movement type, and each movement type has a cost for every kind of terrain. A unit keeps moving while the costs it has paid stay within its Move. On the Movement page, select a type and choose Edit to change its costs. Costs can use tenths, such as 1.5, and × means the terrain cannot be entered. Walls and doors are listed separately so they can be opened up too. To change where a single class can go, give it a different movement type on the Classes page: a class given Flying crosses water and cliffs.

Flying units can pass over houses and other buildings but cannot end their move on them. On the Terrain page, set Flyers cannot stop here to No for a terrain to let them land there. A flyer still needs a cost other than × for that terrain on the Movement page.

The game does not store terrain names as text, so each kind is named after the published terrain it matches. Some kinds share the same costs, such as plain and grassland, and a few could not be matched and are listed as unidentified.

Your changes are kept in a project file. Save project writes a small .bwproj file that lists only what you changed, so it is easy to back up or share. A project only opens with the disc it was made for.


Game rules

The Rules page changes how the game itself plays:

Parry: Normal lets units with the Parry skill parry, which cancels a hit completely; Always makes every unit holding a usable weapon parry every hit; Never turns parrying off.
Shield block: a successful block takes the shield's Might off the hit. Normal rolls against the block chance; Always makes every block succeed; Never turns shield blocking off.
Shield guard on a failed block: Off is the game's own behaviour. Quarter, Half or Full lets that part of the shield's Might (rounded down) count as Defense when a block roll fails against a physical attack. Knives and other attacks that ignore Defense also ignore the guard. The "at least 1" choices never give less than 1. Guard and Desperation do not reduce this bonus. Part of the Might always counts as Defense and a successful block adds the rest, so the battle forecast, the status screen and the equipment windows show it: with a quarter of Might 5, Def 7 +5 becomes Def 8 +4. The Live page applies the battle part; the displays show the guard on an exported disc. Discs exported with this setting by versions 0.93 to 0.108.1 could misbehave when leaving town; export them again with this version.
Shield training speed and Weapon training speed: how much a shield or weapon level rises on each successful training roll in battle, in tenths of a level (game defaults 4 and 1, that is 0.4 and 0.1 of a level). 0 stops that kind of level from rising in battle. Shields train only when a block roll happens, so a unit that kills its attacker first with Vantage gets no shield training.
Attack speed in avoid: avoid is attack speed times 2 in the game; choose times 1, 2 or 4.
Battle stats: which stat each part of a fight uses, chosen from Strength, Agility, Defense, Mind and Max HP: physical attack (game: Strength, plus weapon Might), magic attack (Mind, plus spell Might), physical defense (Defense), magic defense (Mind; Mag on the status screen is the Mind stat itself, magic defense shows as Def in a forecast against magic), attack speed (Agility; avoid is twice attack speed, so this also sets avoid), the stat that offsets weapon and shield weight (Strength) with the share of it that counts (half in the game; all, a quarter or an eighth), and healing (Mind, plus the staff's power). Each stat is counted with its equipment and skill bonuses.
Hit and critical: hit is the weapon's accuracy plus the unit's weapon level (at most the class's limit) plus bonuses. Hit adds can use the weapon level (game), a stat, or nothing. Critical is the weapon's critical plus the weapon level above a threshold (game: 50) plus bonuses; Critical adds can use that, the full weapon level, a stat, or nothing, and the threshold goes from 0 to 100.
Damage: damage is attack minus defense minus any block reduction. In the game a hit that does not get past defense deals nothing; it can be set to deal 1 instead. A critical hit adds its bonus on top either way. Knives leave the attack stat out and add a random amount from 0 up to Strength in each hit instead; the stat knives add (Strength, Agility, Defense, Mind or Max HP) and whether they add a random part of it or all of it can be changed.
Training roll ceiling: a training roll needs a random number below this ceiling minus 3 times the current level (game value 190), so high levels train slowly. Raise it to keep high levels training.
Training from failed attempts: the game lets misses and failed blocks train only below level 20; At every level removes that limit.
Durability: each use of an item with a durability grade costs the amount for its grade (game values 1 for S, 2 for A, 3 for B, 4 for C, 5 for D, 6 for E and 7 for F; shields cost 4 times as much). After each use the item can break, at a chance set by its durability band: 0% at 61 or more, 1% at 41 to 60, 2% at 21 to 40, 4% at 1 to 20 and 100% at 0. The lowest durability of each band and each band's break chance can be changed; the bands also set the condition shown in item menus, whose text keeps the game's numbers. A weapon is used when it hits, when its strike fails and when it parries; bows and their arrows are also used on a miss.
The durability marks in the game's item lists are blue (61 or more), green (41 to 60), yellow (21 to 40), orange (1 to 20) and red (0); the Rules page shows each band's colour.
Items above the unit's level: when an item's rank is above the unit's level, each strike can fail, at a chance of the difference times 5% in the game. A failed strike misses and still uses the weapon. The battle forecast does not show this chance. It can be set from never to 16% per level.
Shield training with Vantage: a unit that strikes first through Vantage normally gets no shield training, because the enemy's attacks never reach its shield. With this rule it gets one shield training roll per battle if it holds a shield it can use, counted as a failed or a successful block.
Injury: the base chance that a hit cripples the target (game value 3, 0 to 100). A knife adds 6 (also adjustable, 0 to 100), Flourish 33, and some items more. Units with Robust or Robust+ are never crippled.
Partner range: how close a partner has to be for its hit and critical bonuses (game value 2 hexes, 1 to 10).
Blessing: its range (game value 3 hexes) and the most HP it heals each turn (game value 3, 0 to 30).
Critical hit bonus damage: a critical hit adds a random amount between the low and high values, both included (game default 10 to 20). The low value cannot be higher than the high value.
Experience after a fight: Normal uses the game's formula; a fixed amount from 1 to 100 replaces it and gives every unit exactly that much after each fight it takes part in (100 is a full level).
Experience formula: battle experience comes only from defeating an enemy. It is the enemy class's experience value plus a bonus for the level difference (enemy level minus the unit's level), then 20% more with the experience skill, kept between 0 and the highest amount. Each of the 16 level difference bonuses (game values -40 at 8 or more levels below, rising to +15 at 7 or more above) and the highest amount (100) can be changed. The class experience values are edited on the Classes page.
Stat limits: the most a character can gain above the class base. HP bonus (game default 50, up to 127), Strength, Agility, Defense and Mind bonuses (default 15, which is also the most the game can store), and Luck (default 20, up to 31). Lower limits make characters plateau sooner.

Staff experience: using a staff gives the staff's level plus a base amount (game value 6) plus a random amount from 0 up to the random bonus (game value 3), minus a fifth of the unit's level, never below 0.

Rules apply to the whole game, enemies included, and are written into the game program when you export. Each rule was checked in a running game before being offered. A rule is left alone on a disc whose program has different code at that point, such as another mod.


Skills

The Skills page explains every skill in the game, all 90 of them: what it does, how it works, whether it is a command, and which starting characters and classes have it. A line under each name says how the explanation is known: checked in a running game, read from the game program, or taken from the game's own description where the skill has not been traced in the program yet. Search finds skills by name or description. Skill, item, class, unit, terrain and movement type names are the ones the English v2.3 release shows in game; where the game uses one name for several entries (three Balmungs, or the many "Man" classes), the second and later ones get a number such as (2). Skill names include Huntsman, Lethargy (1 hex less move) and Slow Start (1 hex less until level 15).

Skills that help nearby allies (Commander, Safe Zone, Charisma, Leader, Protector, Resistor) add their bonus once for every unit with the skill in range, so they stack; a unit's own skill does not help itself. Supporter works when two units with it are within 3 hexes and does not stack.

Where the game's numbers can be changed, the card also shows the game's formula with those numbers:

Commander: the hit each ally gets for every unit with Commander within 3 hexes (game value 10).
Safe Zone, Charisma, Leader, Protector and Resistor: the hit, avoid, defense or magic defense each ally gets for every unit with the skill in range (game values 15 hit and 15 avoid, 3 hit, 5 avoid, 5 defense, 5 magic defense).
Supporter: the hit and critical a unit gets while another unit with Supporter is within 3 hexes (game values 20 and 4; critical can be 0, 1, 2, 4, 8 or 16).
Critical: what the Critical skill adds to critical (game: the unit's level; twice or four times the level, half of it, or nothing).
Battle Cry: the hit and attack each use adds to the unit's next fight (game values 10 and 3), and the most uses before a fight (game value 6, 1 to 15). The limit also applies to enemies deciding whether to use it.
Evasion: the avoid bonus while Evasion is active (game value 50, up to 200).
Celerity: the hexes added to move while on foot (game value 1, up to 3); mounted units, wyvern riders included, do not get Celerity.
Slow Start: the hexes taken off move, mounted or on foot (game value 1, up to 3).
Camouflage: how much the terrain avoid of a unit with Camouflage is multiplied (game: one and a half times; no bonus, twice or two and a half times).
Armsthrift: what Armsthrift adds to the chance that a weapon use costs no durability (game value 20, up to 100).
Mug and Mug+: the chance to steal on a hit is the unit's level divided by 10, plus a base (game value 3 for each skill), plus steal bonuses on the unit's items.
Despoil: after a unit with Despoil defeats an enemy, its side gains the enemy's level times the gold per level (game value 4; 1 to 32) plus a random amount up to the random extra (game value 50, up to 999).
Watchful: how many hexes away a unit with Watchful uncovers enemies using Hide or Obfuscate (game value 3, up to 10).
Aura ranges: how far Commander, Leader, Safe Zone, Supporter, Resistor and Protector reach (game value 3) and Charisma (game value 5), from 0 to 10 hexes. 0 turns the skill off. The area the map shows for the skill follows the range; Leader has no area on the map.
Provoke: how far away an enemy can be provoked (game value 5, 0 to 10 hexes). 0 removes Provoke from the menu.

Iaido: when attacking with a sword, half the unit's weapon level plus a base chance (game value 40). The counter that follows gets extra critical chance (game value 3).
Knock Away: when attacking, half the unit's weapon level plus a base chance (game value 30).
Spearbane, Swordbane, Axebane, Arrowbane and Magicbane: when attacked with that kind of weapon, a chance equal to the attacker's hit rate, up to a highest chance (game value 33).
Parry: the chance is the weapon level plus a bonus, halved (game value 10).
Pursuit: an extra attack when the unit's attack speed beats the enemy's by at least the speed lead (game value 5).
Shieldfaire: a bonus to shield block chance (game value 18).
Sunder: a critical chance bonus for the attack it is used on (game value 25).
Desperation: a hit chance bonus for the attack it is used on (game value 22). In the game the unit's defenses drop to 0 and the enemy always hits; either can be changed.
Flourish: in the game it halves the unit's attack for that attack; the full attack can be kept instead. It also adds to the chance that the hit cripples (game value 33, 0 to 100).
Strikes: how many times Astra strikes (game value 5), Triple-Shot fires (3) and Double-Shot fires (2), each from 1 to 7.
Pulverize: in the game the first hit has double attack and the unit's own defenses drop to 0; the normal attack and the defenses can each be kept instead.
Adept: the attack speed it needs (game value 5, 0 to 20), the bonus added to the weapon level before halving in its chance (game value 10, 0 to 200), and how many times it strikes (game value 2, 1 to 7).
Expert: how much lower an item's rank counts when the game checks the unit's level (game value 7, 0 to 20).
Limited: the highest rank the unit uses normally (game value 3) and the level items above it count as needing (game value 50).
Vengeful: the chance for each point of damage taken (game value 3%, 1% to 5%), and whether it needs an axe or works with any weapon.
Axe Guard: the bonus added to the axe level for its block chance (game value 25, 0 to 100).
Focus Chant: the random attack raise, set as a low and a high percentage (game values 10% and 30%), on the Game rules page.
Weapons for commands: which weapons Aim, Deadeye (with Double-Shot and Triple-Shot), Pulverize, Throw, Astra, Focus Chant and Flourish (with Desperation) can attack with. Each can keep the game's choice, take one weapon type, or take any weapon. The unit must still be able to use the weapon, and a class with no artwork for that weapon type shows an empty hand in the attack animation (a Spear Knight with a lance, for example). Iaido's weapon (in the game a sword or blade) and Huntsman's weapon (in the game a bow, crossbow or ballista) can be changed the same way. Iaido can also be set to prepare its counter bonus after a hit that does 0 damage, a parry, or a hit cancelled by a bane skill, not only after a miss.
Auras: for Commander, Leader, Safe Zone, Charisma, Resistor and Protector, whether the holder also helps itself and whether several holders add up or count once. Supporter can be set to work without a partner. Celerity can be given to mounted units too. Vantage can be set to work against attackers of any speed. In the game a unit that takes damage stops counterattacking unless it has Counter; this can be changed so every unit keeps countering.
Aim: a hit chance bonus for the attack it is used on (game value 33).
Deadeye: a hit chance change for the attack it is used on (game value -15).
Focus Chant: a hit chance bonus for the attack it is used on (game value 30).
Throw: a hit chance bonus for the throw (game value 10).
The equipment window shown while choosing one of these commands shows the same bonus as the battle.

After moving: each command skill can be allowed or not allowed after the unit moves. In the game, Aim, Deadeye, Sunder, Pulverize, Overwatch, Axe Guard, Windsweep, Battle Cry, Steal, Provoke, Evasion, Silence and Imbue are only offered before moving. Double-Shot, Triple-Shot, Astra, Focus Chant, Guard, Search, Return and Convert are offered before or after. Throw, Mercy, Desperation, Flourish and Deathmatch are offered after moving unless the unit's weapon rules it out ("Weapon decides"). Hurry is left out, because allowing it after a move gives endless movement.

Waits: after use, Astra, Focus Chant and One-Two return 6 turns later, Silence 10, Triple-Shot and Evasion 4, Double-Shot, Imbue and Flourish 3. Each wait can be set from 1 (every turn) to 30. For Astra, Focus Chant, Triple-Shot, Double-Shot and Flourish the game sets the wait again after the fight, one higher; the setting changes both.
Steal: Steal, Robbery and Mug+ share 3 steals per map (2 with Mug+); the limit can be removed.
Canto: in the game Canto is not offered after a fight in which the unit took damage; it can be offered anyway.
Guard: in the game a guarding unit's own defense and avoid are halved; this can be turned off.
Provoke: how many of its own turns a provoked enemy stays provoked (10 in the game).
Debility: what a unit with Debility has its HP, Strength, Defense, Agility and Mind divided by (2 in the game; 1 turns it off).
Weapon skills: which weapon type Pitchfork, Lance and Blade let a unit use (in the game pitchforks, lances and blades). Lances still need a mounted class.
Miracle: how much hit the attacker loses when a killing hit is rolled again (10 in the game; at 100 a killing hit never lands).
Hateful: how many of its own turns a unit with Hateful stays Provoked at whoever attacked it (10 in the game).
Hurry: how many hexes farther a unit moves after choosing Hurry (1 in the game).
Deathmatch: how many rounds of fighting it starts (5 in the game; a normal attack has 1).
Robbery: the chance to take a defeated enemy's items (25% in the game) and how far away the enemy may be (range 0 or 1 in the game).
Swimmer: water costs the same as plain ground. In the game this works mounted or on foot; it can be limited to units on foot.
Paragon: extra experience on top of the normal amount: none, 10%, 20% (game value), 25%, 33% or 40%. It only counts while the unit is at or below a set level, 10 in the game.

Which characters and classes have a skill is set on the Characters and Classes pages. Skills that are always on, such as Robust, have no chance to change.


Shops

The Shops page lists the 24 shops the game's scripts build: 13 at the base, named by what they sell (swords, knives and blades; spears; axes; bows; arrows; shields; magic; remedies; and five material traders), and 11 on battle maps, named by the battle and the kind of shop the spot on the map opens. Each item is sold one of three ways: always for sale; from a stock that the game refills over time (each stocked item has a stock number); or as a special purchase that sets off an event when bought. Select a shop to see its items; selecting an item shows its base price and how it is sold. Change item sells another item in that place (a stocked item keeps the stock of the item it replaces), Add item adds an item that is always for sale after the last one, and Remove item takes one out (a shop keeps at least one item). Restore this shop puts the disc's version back. The changes are made in the shop's script, so each is one step for Undo, is kept in the project, and is written into every copy of the script when you export a disc. The stable and the furniture shop are changed on their own pages.
The Stable is listed first. Select a horse to change what the stable charges. Below the list, Horses for sale each chapter sets which horses the stable offers: how many of each, the chapters with the Spry and Tough Horses, the chances of the Strong Horse and of one rare horse, and how many horses in all, with Thin Horses filling the rest. The Kingfisher Pavilion is listed too. Any unit can order changes its server: while the Pavilion serves meals, talking to the server opens your unit list, so any unit in your army can order and eat, one after another, instead of only the units seated there. Each unit still eats once a chapter.
The Atelier is listed next, once for each craftsman: Orlando makes 20 weapons and shields, each from a base weapon or shield and three materials, and Lumiere makes 10 magic tomes, stones and potions from three materials. To change a recipe, open the item it makes on the Items page and edit its Atelier recipe (up to four ingredients; the first is required). The Items page also lists which recipes use an item. A synthesized item's own stats, such as Might or durability, are edited like any other item.


Maps

The Maps page shows the map of each of the game's 42 battles as the game paints it: the painted picture, the river and other water as they look when the battle starts, and the hex grid on top. Hover over a hex to see its position and terrain. Numbered markers show the spots that add a command to a unit's menu, named as the game's menu names them: gates and doors to open, chests, villages to search, places to seize or investigate, shops, drawbridges and the hex to withdraw from. Units shows where every unit stands when the battle opens, read from the map's own placement table: enemies as red squares, other armies (guests and third parties) as green squares, leaders and bosses with a gold edge, and the hexes where you can place your own units in blue. Hover over a unit to see its name, class, level and army. Arrivals shows the reinforcements the battle's scripts bring in later: a white square edged in the side's color at the hex where they arrive, with the turn number when the script names one turn, the first turn and a plus (such as 2+) when units come every turn for a while, and without a number when an event in the battle brings them. Of the 406 arrivals across the game's battles, 316 come on one turn, 16 every turn over a range of turns, 18 when a unit uses a spot (such as a Withdraw hex), 29 at the start of a turn the battle picks itself (shown as when the battle's conditions are met) and 27 through other events, of which those set off by one unit talking to another name both units; 125 also depend on something the battle checks, such as an event flag, and say so. The turns were checked in a running game: in quest 6, Cruel Brothers, the first reinforcement came in at hex 2, 1 on turn 5 as shown. Arrivals include the recruitable characters who join during a battle, such as Lynette in story mission 14. Hover over it for the unit, its class and level, when it arrives and whether it comes in from the map edge; the side panel lists the arrivals by when they come. The side panel lists the spots, how many units each side starts with and who leads them, the battle's armies and the kinds of terrain on the map. Terrain colors colors each hex by its terrain over the picture; with Map art turned off the colors are shown alone. Size draws the map small, medium or large. The 41 map files on the disc that no battle uses (some belong to quests that are listed in the game's data but never offered) are listed at the end, with terrain only. The page is for reading.


Battle animations

The Battle animations page shows the animation each class plays in battle. A class has one set of animations for any weapon and can have others for certain weapon types, such as a sword set and a spear set; a few characters, such as Theodore and Ruby, have rows that give them a set of their own. Most characters wear their own colours in their class's set: Adel and Leon share the Spear Knight's drawing, Adel in palette 5 and Leon in palette 6. The game looks first for rows made for the unit, then for rows for anyone in the class; within each it prefers a row for the exact item held, then for the weapon type, then the row for any weapon. Colours follow the same order, with rows for the player, enemy and allied sides in between. Choose a set, a motion and colours to watch it play at the game's speed, or step through it a frame at a time. Motions keep the names they have in the game files; m0_0 is the standing pose. The 24 sets on the disc that no class uses are listed at the end, among them a rider on a winged horse and a third set of colours for the Spear Knight.

Choose Change beside a row to give it another set or other colours: any set on the disc, including those no class uses, or any palette the class's sets carry. The change applies to every unit the row covers, is saved in the project and is written to the exported disc. A battle stops when a class plays a motion its set does not have, so only sets with every motion of the row's own set are offered (checked in a running game: the Spear Knight given the mounted winged set froze after riding in; on foot, given the winged set that has all his motions, the fight played through). Units keep their map sprites. For a set no class uses, the page lists the classes whose sets it can replace.

Each class also has a map sprite, the figure units of the class show on the battle map, with a second one while they hold a shield; Change gives the class another class's map sprite, copied whole with its frame count and size (checked in a running game: Spear Knights on foot given the Wyvern Knight's on-foot sprite showed it after dismounting). The sets of art 008, 021 (the winged rider), 023, 092, 103 and 120 have no map sprite of their own, so a class given one of them needs another class's map sprite. A colour change was checked in a running game: with Adel's row set to palette 6 he fought in Leon's colours.

Events

The Events page shows the game's 3,983 event scripts (story scenes, map events and base events) as readable commands. Values are numbers, text or local values (v0, v1 and so on); if, else and while show the branches and loops; "run event" starts another event and "wait" pauses for a number of frames. Commands carry the names the game itself gives them (for example SetEventFlag, LaunchMapEvent or GUnitCalcMercenaryCost), read from the opened disc, so searching for a name lists the events that use it. Type an event number and press Enter to jump to it, or type text or a number (for example an item number) to list every event that contains it.

The numbers in an event can be changed. The list beside the script shows every number with the command it belongs to and which argument it is; select one and choose Edit (Ctrl+E). Turns, hexes, units, items, gold and event flags are all numbers in the scripts: for example, the turn a reinforcement arrives. The script shows the new value at once and the number is marked as changed. The change is saved in the project and written into every copy of the event when you export a disc (some events are stored three times). The scripts are stored compressed, packed together in archives. A changed script that becomes larger than its space makes room by moving the files stored after it in the same archive; when the archive needs more room than it has, it moves to unused space at the end of the game's data file (about 90 MB on the English disc, 80 MB on the Japanese one) and the disc's index of archives is updated. The archives that hold the game's base data (items, characters, classes and so on) never move, so events stored there (events 1 to 1000 keep one of their copies there) can only grow a little; a value that needs more room than that is refused when you apply it. Checked in a running game: a disc with quest 6's archive moved and every file in it shifted played normally. Checked in a running game: quest 6's first reinforcement, moved from turn 5 to turn 3, arrived on turn 3 on the exported disc.

The lines of an event can be changed on the Lines tab, which lists every command, indented under the if or while it belongs to. Add after adds a command after the selected line: choose it by name and type its arguments, separated by commas, as numbers (12, -1 or 0x2A), text in double quotes or local values (v0, v1); a command is only accepted with an argument count that the game's own scripts use for it, and the form says which. Duplicate adds a copy of the selected line, Remove deletes it (an if or while takes the lines under it along), and Up and Down move it within its part of the script. Each change is one step for Undo, and Restore the event's lines puts the disc's version back. The project keeps the event's whole new script and only opens with a disc whose original event matches; numbers changed earlier in the event become part of it. The stable and furniture price events are left to their own pages. Changing lines changes what the game does at that point, so play the exported disc to check. Checked in a running game: a reinforcement line added under quest 6's turn 2 brought that unit on turn 2.

The whole script can also be edited as text: choose Edit text above the script, change it, and choose Apply text. The text uses the same forms the page shows: four spaces of indent for each level, the lines of an if, else or while one level further in, commands with their arguments in parentheses, numbers, text in double quotes (with \" for a quote, \n for a new line and \\ for a backslash), local values such as v0, and parentheses around every operator, as in (v0 == 5). A mistake is reported with the line it is on, and the cursor moves there; Cancel puts the text back. The result is kept like a change made on the Lines tab. Every event on both discs reads back from its text to exactly the same script.


Live game

The Live game page changes the game while it runs in PCSX2, so you can try a change without playing up to the point where it matters, or test a mod on any unit you like.

1. In PCSX2, turn on PINE (Settings, Advanced) and keep the default slot, 28011.
2. Start Berwick Saga in PCSX2 from the same edition as the disc opened in Berwick Workshop, and load a battle.
3. On the Live game page, choose Connect.

The page lists every unit on the current map: yours, enemies and allies, with class, level, HP and position. Select a unit to change its class, level, current HP, stat bonuses, weapon levels, personal skills and items (with their uses), then choose Apply to the game. Refresh units reads the map again after you move on in the game. Some changes show at once; class and stats show when the game next works them out, for example when you open the unit's screen again or start a fight. Under Horse you can give a unit any of the 16 horses, change its horse, or set the horse's HP; choosing a horse fills in its full HP. A unit on foot can then choose Mount in the game. A riding unit keeps a horse until it dismounts in the game; after that the horse can be taken away (No horse).

Try this project's rules writes every rule you have changed in the current project into the running game, so a rule can be tested before you export a disc. A rule is left alone if the running game has different code at that point.

Next sortie loads lets you test on any battle without playing up to it. While the game is at the base, choose a story mission or quest battle (listed by their titles, such as Breaking Bridges or Cruel Brothers, in English on both editions) and choose Send sorties there, then start any mission or quest that the base offers: the game loads the chosen battle with its own map, units and events, and your own units deploy as usual. Use each sortie's own battle, Undo all changes, or restarting PCSX2 puts the missions back; this is not kept in a save. A battle that is already on the map is not changed.

Undo all changes puts back everything the page changed in the running game. Anything the game has changed again since, such as HP after a fight or the uses of an item, is left as it is. Loading a save state undoes it too. Nothing on the disc, in your memory cards or in your save states is changed; a save you make in the game while changes are active does keep them.

Berwick Workshop connects only to PCSX2 on this computer (127.0.0.1), and only after you choose Connect. Before showing anything it checks that PCSX2 is running Berwick Saga and that its program matches the opened disc.


Mechanics

The Mechanics page explains how the game's systems work: damage, hit and avoid, shields, critical hits, growth, experience, movement, mounting and horses. Each entry shows the formula, a short explanation, how well it is verified (published by players, found in the game program, or confirmed in a running game), and buttons to the values you can change today. Formulas that are not yet found in the game program cannot be changed yet, and the page says so.


Exporting a disc

Export disc writes a new ISO with your changes applied, ready to load in PCSX2. Choose a new file name; the original image and any existing file are never overwritten. If the disc's two copies of a table disagree at a value you changed, export stops rather than replace that difference. Before anything is kept, the original is checked against the fingerprint taken when it was opened, both copies of each changed table on the disc are updated, and the changed bytes are read back from the new file. Exporting needs free space for a full copy of the disc, about 4 GB. Cancel stops the export and removes the unfinished file.


Supported discs

Japanese retail release (SLPS-25497, disc version 1.02)
English translation v2.3 (SLPS-25497, disc version 1.02)

Modified copies of these discs, such as an exported disc or another mod built on them, open as a modified disc. Their data is read as it is on that disc. Other images can be opened to view their disc details only.


Getting started

1. Run Berwick Workshop.exe. Nothing needs to be installed.
2. Click Open ISO and choose your disc image, or drag the ISO onto the window.
3. To compare discs, click Compare ISO and choose the other disc. You can also drag two ISOs onto the window at once.

Checking a disc reads the whole image once, which takes a few seconds on a fast drive.


Notes on values

A character's base stats are the class base plus the character's own bonus.
Mounted and dismounted forms of a class are listed separately.
Range follows the game's own counting, where 0 means adjacent only.
Durability grades run from S (best) to F. A full item shows 100; the durability pool is stored one higher (101).
Mind growth is shown exactly as stored on the disc. Published growth tables list half of this value.


Keyboard shortcuts

Ctrl+O     Open a disc
Ctrl+Shift+O     Choose a comparison disc
Ctrl+F     Search the current list
Ctrl+E     Edit the selected item, character, class or movement type
Ctrl+N     New item
Ctrl+Z, Ctrl+Y     Undo, redo
Ctrl+S     Save the project
Ctrl+Shift+S     Save the project under a new name
Escape     Cancel a disc check or export


Your files

Berwick Workshop never changes your original ISO files, memory cards, save states or PCSX2 settings, and it does not connect to the internet. The only disc images it writes are the new files you choose when exporting. The Live game page connects only to PCSX2 on this computer, and only when you choose Connect.


Credits

Item names, character and class lists, and table positions build on the Berwick Saga editor by MinN-11. See Licenses.txt.

Berwick Saga and all related names belong to their owners. This is a free fan tool and is not affiliated with or endorsed by the publisher or developer.
